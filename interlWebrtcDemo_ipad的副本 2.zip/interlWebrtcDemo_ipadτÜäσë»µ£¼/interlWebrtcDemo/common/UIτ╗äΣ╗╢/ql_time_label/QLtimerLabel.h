//
//  QLtimerLabel.h
//  BVCforIphone
//
//  Created by 乔乐 on 17/3/19.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
@interface QLtimerLabel : UILabel
@property(nonatomic,assign)int hour;
@property(nonatomic,assign)int minute;
@property(nonatomic,assign)int second;
@property(nonatomic,strong)NSTimer * Timer;
- (NSString*)stop;
- (void)hidden;
- (void)appear;
@end
