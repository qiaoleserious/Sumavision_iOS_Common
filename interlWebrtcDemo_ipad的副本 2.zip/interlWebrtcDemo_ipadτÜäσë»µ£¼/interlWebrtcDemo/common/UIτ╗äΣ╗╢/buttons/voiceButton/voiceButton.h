//
//  voiceButton.h
//  来电铃声
//
//  Created by 乔乐 on 2017/9/13.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface voiceButton : UIButton

@end
