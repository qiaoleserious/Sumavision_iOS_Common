//
//  talkItemView.m
//  BVCforIphone
//
//  Created by 乔乐 on 17/3/17.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "talkItemView.h"
#import "UIView+createFrame.h"
#import "voiceButton.h"
#import <objc/runtime.h>

@interface talkItemView()
@property(nonatomic,strong)voiceButton * imageV;

@property(nonatomic,strong)UILabel * namelabel;

@end
@implementation talkItemView

- (talkItemView *)initWithFrame:(CGRect)frame
                        andName:(NSString *)name
                   andImageName:(NSString *)imageName
{
    self = [super init];
    self.userInteractionEnabled = YES;
    self.name = name;
    self.imageName = imageName;
    self.frame=frame;
    self.imageV = [[voiceButton alloc]initWithFrame:[UIView getRectWithX:0 Y:0 width:frame.size.width andHeight:frame.size.width]];
    self.imageV.frame = CGRectMake(0, 0, self.imageV.frame.size.width, self.imageV.frame.size.width);
    [self.imageV setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [self.imageV addTarget:self action:@selector(btn:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.imageV];
    return self;
}


- (talkItemView *)initWithFrame:(CGRect)frame
                        andName:(NSString *)name
                andSelectedName:(NSString *)selectedName
                   andImageName:(NSString *)imageName
           andImageSelectedName:(NSString *)seclectedName
                      andSelect:(BOOL)select
                      andHidden:(BOOL)hidden
{
    self = [super init];
    self.name = name;
    self.selectedName = selectedName;
    self.imageName = imageName;
    self.frame=frame;
    self.imageV = [[voiceButton alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.width)];
    [self.imageV setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    self.imageV.selected = select;
    [self.imageV addTarget:self action:@selector(btn:) forControlEvents:UIControlEventTouchUpInside];
    [self.imageV setImage:[UIImage imageNamed:seclectedName] forState:UIControlStateSelected];
    [self addSubview:self.imageV];
    self.namelabel = [[UILabel alloc]initWithFrame:CGRectMake(0, self.imageV.frame.size.height+10, self.imageV.frame.size.width, 20)];
    self.namelabel.text = name;
    self.namelabel.textAlignment = NSTextAlignmentCenter;
    self.namelabel.font = [UIFont systemFontOfSize:10];
   
    if (select ==0 )
    {
        [self.namelabel setTextColor:[UIColor whiteColor]];
    }
    else
    {
        UIColor *color = [[UIColor alloc]initWithRed:125/255.0 green:162/255.0 blue:198/255.0 alpha:1];
        [self.namelabel setTextColor:color];
    }
    [self addSubview:self.namelabel];
    if (hidden)
    {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(hidden) userInfo:nil repeats:NO];
        [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
    }
        return self;
}

- (NSTimeInterval)timeInterval
{
    return [objc_getAssociatedObject(self, _cmd) doubleValue];
}

- (void)setTimeInterval:(NSTimeInterval)timeInterval
{
    objc_setAssociatedObject(self, @selector(timeInterval), @(timeInterval), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
//runtime 动态绑定 属性
- (void)setIsIgnoreEvent:(BOOL)isIgnoreEvent{
    // 注意BOOL类型 需要用OBJC_ASSOCIATION_RETAIN_NONATOMIC 不要用错，否则set方法会赋值出错
    objc_setAssociatedObject(self, @selector(isIgnoreEvent), @(isIgnoreEvent), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)isIgnoreEvent{
    //_cmd == @select(isIgnore); 和set方法里一致
    return [objc_getAssociatedObject(self, _cmd) boolValue];
}

- (void)setIsIgnore:(BOOL)isIgnore{
    // 注意BOOL类型 需要用OBJC_ASSOCIATION_RETAIN_NONATOMIC 不要用错，否则set方法会赋值出错
    objc_setAssociatedObject(self, @selector(isIgnore), @(isIgnore), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (BOOL)isIgnore{
    //_cmd == @select(isIgnore); 和set方法里一致
    return [objc_getAssociatedObject(self, _cmd) boolValue];
}
- (void)resetState{
    [self setIsIgnoreEvent:NO];
}

- (void)btn:(voiceButton*)btn
{
    self.timeInterval =self.timeInterval == 0 ?defaultInterval:self.timeInterval;
    if (self.isIgnoreEvent){
        return;
    }else if (self.timeInterval > 0){
        [self performSelector:@selector(resetState) withObject:nil afterDelay:self.timeInterval];
    }
    self.isIgnoreEvent = YES;
    btn.selected = !btn.selected;
    if (btn.selected ==0 )
    {
         [self.namelabel setTextColor:[UIColor whiteColor]];
        self.namelabel.text = self.name;
    }
    else
    {
        UIColor *color = [[UIColor alloc]initWithRed:125/255.0 green:162/255.0 blue:198/255.0 alpha:1];

        [self.namelabel setTextColor:color];
        self.namelabel.text = self.selectedName;
    }
    [self.delegate todo:self.name];
}


@end
