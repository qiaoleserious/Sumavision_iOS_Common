//
//  loginView.h
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/9.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol loginDelegate<NSObject>
- (void)login:(NSString*)ip;
@end
@interface loginView : UIImageView
@property(nonatomic,assign)id<loginDelegate> delegate;
- (instancetype)initWithDelegate:(id<loginDelegate>)delegate;
@end
