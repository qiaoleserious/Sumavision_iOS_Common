//
//  standbyBackgroundView.h
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol callDelegate<NSObject>
- (void)call;
@end
@interface standbyBackgroundView : UIImageView
@property(nonatomic,assign)id<callDelegate> delegate;
- (instancetype)initWithDelegate:(id<callDelegate>)delegate;
@end
