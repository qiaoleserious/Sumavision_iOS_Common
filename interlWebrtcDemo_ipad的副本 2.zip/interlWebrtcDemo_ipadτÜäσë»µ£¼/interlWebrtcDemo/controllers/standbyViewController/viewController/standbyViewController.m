//
//  standbyViewController.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "standbyViewController.h"
#import "standbyBackgroundView.h"
#import <Woogeen/Woogeen.h>
#import "AppDelegate.h"
#import "conferenceViewController.h"
#import "HTTPManager.h"
@interface standbyViewController ()<callDelegate>
@property(nonatomic,strong)standbyBackgroundView * backView;
@property(nonatomic,strong)NSData * data;
@property (nonatomic) RTCConferenceClient* conferenceClient;
@end

@implementation standbyViewController
- (instancetype)initWithData:(NSData *)data
{
    if (self = [super init])
    {
        self.data = data;
        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:data forKey:@"data"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.backView = [[standbyBackgroundView alloc]initWithDelegate:self];
    [self.view addSubview:self.backView];
    AppDelegate* appDelegate = (id)[[UIApplication sharedApplication]delegate];
    _conferenceClient=[appDelegate conferenceClient];
    // Do any additional setup after loading the view.
}

- (void)call
{
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
   
    NSString * ip = [defaults objectForKey:@"userIP"];
    NSDictionary *params = [[NSDictionary alloc]initWithObjectsAndKeys:@"", @"room", @"user", @"username", @"presenter", @"role", nil];
    [HTTPManager post_with_Url:[ip stringByAppendingString:@"createToken/"] param:params log:@"登录" haveHud:1 sucHandle:^(NSData *data)
     {
         [_conferenceClient joinWithToken:[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding] onSuccess:^(RTCConferenceUser *user) {
             dispatch_async(dispatch_get_main_queue(), ^{
                 NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                 [defaults setObject:user.getUserId forKey:@"localStreamGetUserId"];
                 NSLog(@"%s 第%d行 userId:%@",__func__,__LINE__,user.getUserId);
                 conferenceViewController * conference = [[conferenceViewController alloc]init];
                 [self presentViewController:conference animated:YES completion:nil];
             });
         } onFailure:^(NSError* err) {
             NSLog(@"Join failed. %@", err);
         }];
     } falhandel:^(NSError *error) {

     }];
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
