//
//  standbyViewController.h
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface standbyViewController : UIViewController
- (instancetype)initWithData:(NSData*)data;
@end
