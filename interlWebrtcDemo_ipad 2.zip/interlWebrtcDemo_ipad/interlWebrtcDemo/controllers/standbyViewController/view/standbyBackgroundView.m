//
//  standbyBackgroundView.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "standbyBackgroundView.h"
#import "voiceButton.h"
#import <Masonry.h>
#import "UIColor+hex.h"

@interface standbyBackgroundView()
@property(nonatomic,strong)voiceButton * callBtn;
@end
@implementation standbyBackgroundView
- (instancetype)initWithDelegate:(id<callDelegate>)delegate
{
    if (self = [super init])
    {
        self.frame = [UIScreen mainScreen].bounds;
        self.delegate = delegate;
        self.image = [UIImage imageNamed:@"standbyBackground.png"];
        self.userInteractionEnabled = YES;
        [self createUI];
    }
    return self;
}

- (void)createUI
{
    self.callBtn = [[voiceButton alloc]initWithFrame:CGRectZero];
    [self addSubview:self.callBtn];
    [self.callBtn addTarget:self action:@selector(call) forControlEvents:UIControlEventTouchUpInside];
    //    [self.callBtn addTarget:self action:@selector(pressLogin:) forControlEvents:UIControlEventTouchDown];
    //    [self.callBtn addTarget:self action:@selector(cancelLogin:) forControlEvents:UIControlEventTouchUpOutside];
    [self.callBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.top.mas_equalTo(self.frame.size.height*1046/1530);
  make.size.mas_equalTo(CGSizeMake(self.frame.size.width*503/2037,self.frame.size.width*503/2037*100/500));
    }];
   
    [self.callBtn setImage:[UIImage imageNamed:@"发起通话.png"] forState:UIControlStateNormal];
    [self.callBtn setImage:[UIImage imageNamed:@"发起通话selected.png"] forState:UIControlStateSelected];
    
}
#pragma mark - call
- (void)call
{
    [self.delegate call];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
