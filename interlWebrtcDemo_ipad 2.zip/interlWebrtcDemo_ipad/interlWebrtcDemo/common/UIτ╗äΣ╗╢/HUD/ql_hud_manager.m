//
//  ql_hud_manager.m
//  BVCforIphone
//
//  Created by 乔乐 on 2017/6/26.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "ql_hud_manager.h"
//#import "ql_base_hud.h"
@interface ql_hud_manager()

@end
@implementation ql_hud_manager
static ql_hud_manager * manager = nil;
+ (instancetype)manager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^
    {
        if (!manager)
        {
            manager = [[ql_hud_manager alloc]init];
        }
    });
    return manager;
}

- (instancetype)init
{
    if ((manager = [super init]))
    {
         [SVProgressHUD setDefaultStyle:SVProgressHUDStyleLight];
         [SVProgressHUD setDefaultAnimationType:SVProgressHUDAnimationTypeFlat];
         [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
         [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(handleNotification:)
                                                     name:SVProgressHUDDidReceiveTouchEventNotification
                                                   object:nil];
    }
    return manager;
}

- (void)handleNotification:(NSNotification *)notification
{
    if([notification.name isEqualToString:SVProgressHUDDidReceiveTouchEventNotification])
    {
        [SVProgressHUD dismiss];
    }
}

+ (void)show
{
    [ql_hud_manager manager];
    [SVProgressHUD show];
}

+ (void)showWithStatus:(NSString*)status
{
    [ql_hud_manager manager];
    [SVProgressHUD showWithStatus:status];
}

+ (void)dismiss
{
    [SVProgressHUD dismiss];
}

+ (void)dismissWithDelay:(NSTimeInterval)time
{
    [SVProgressHUD dismissWithDelay:time];
}

+ (void)showInfoWithStatus:(NSString*)status
{
    [ql_hud_manager manager];
    [SVProgressHUD showInfoWithStatus:status];
}

//#pragma mark - 横屏提示框
//+ (void)showHorizontalInfo:(NSString *)info
//{
//    ql_base_hud * hud = [[ql_base_hud alloc]initWithInfo:info];
//}

@end
