//
//  conferenceView.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "conferenceView.h"
#import "QLtimerLabel.h"
#import "talkItemView.h"
#import "UIView+createFrame.h"
#import "BrightenFilter.h"
@interface conferenceView()<talkItemViewDelegate>
{
    CGRect screenSize;
    
}
@property(nonatomic,strong)QLtimerLabel * timerLabel;
@property(nonatomic,strong)talkItemView * silentItem;
@property(nonatomic,strong)talkItemView * stopItem;
@property(nonatomic,strong)talkItemView * changeitem;
@end

@implementation conferenceView
{
    UILabel* statsLabel;
    BOOL isStatsLabelVisiable;
}
- (instancetype)initWithFrame:(CGRect)frame Delegate:(id<conferenceDelegate>)delegate
{
    if (self = [super initWithFrame:frame])
    {
        self.backgroundColor = [UIColor blackColor];
        self.delegate = delegate;
        [self createdisplayView];
        [self createBtn];
        [self createTimeLabel];
        
    }
    return self;
}

- (void)createdisplayView
{
#if defined(RTC_SUPPORTS_METAL)
    _remoteVideoView = [[RTCMTLVideoView alloc]initWithFrame:CGRectZero];
#else
    _remoteVideoView = [[RTCEAGLVideoView alloc]init];
#endif
    _localVideoView=[[RTCCameraPreviewView alloc] init];
    
    statsLabel=[[UILabel alloc]init];
    isStatsLabelVisiable=NO;
    screenSize =  [UIScreen mainScreen].bounds;
    // local view
    CGRect localVideoViewFrame=CGRectZero;
    localVideoViewFrame.origin.x = screenSize.size.width-screenSize.size.height / 4.0;
    localVideoViewFrame.origin.y = 0;
    localVideoViewFrame.size.width = screenSize.size.height / 4.0;
    localVideoViewFrame.size.height = screenSize.size.width / 4.0;
    _localVideoView.frame=localVideoViewFrame;
//    _localVideoView.layer.borderColor = [UIColor yellowColor].CGColor;
//    _localVideoView.layer.borderWidth = 2.0f;
    _localVideoView.contentMode = UIViewContentModeScaleAspectFit;
    // remote view
    _remoteVideoView.frame=CGRectMake(0, 0, screenSize.size.width*3 / 4.0, screenSize.size.height);
//    _remoteVideoView.layer.borderColor = [UIColor yellowColor].CGColor;
//    _remoteVideoView.layer.borderWidth = 2.0f;

    _remoteVideoView.contentMode = UIViewContentModeScaleAspectFit; // <— Doesn’t seem to work?
    
    
    [self addSubview:_remoteVideoView];
    [self addSubview:_localVideoView];
    
    
    // Stats label
    CGRect statsLabelFrame=CGRectMake(screenSize.size.width-140, 0, 140, 100);
    statsLabel.frame=statsLabelFrame;
    statsLabel.backgroundColor=[[UIColor whiteColor] colorWithAlphaComponent:0.2f];
    statsLabel.textColor=[UIColor blackColor];
    statsLabel.font=[statsLabel.font fontWithSize:12];
    statsLabel.lineBreakMode=NSLineBreakByWordWrapping;
    statsLabel.numberOfLines=0;
}

-(void)setStats:(NSString *)stats{
    if([stats length]==0&&isStatsLabelVisiable){
        [statsLabel removeFromSuperview];
    } else if([stats length]!=0&&!isStatsLabelVisiable){
        [self addSubview:statsLabel];
    }
    statsLabel.text=stats;
}


- (void)createBtn
{
    self.silentItem = [[talkItemView alloc]initWithFrame:CGRectMake(self.center.x-190/2*5*self.frame.size.height/1080, self.frame.size.height-30-250*self.frame.size.height/1080, 190*self.frame.size.height/1080, 250*self.frame.size.height/1080) andName:@"静音" andSelectedName:@"恢复" andImageName:@"静音.png" andImageSelectedName:@"静音selected.png" andSelect:1 andHidden:0];
    self.silentItem.delegate =self;
    [self addSubview:self.silentItem];
    self.stopItem = [[talkItemView alloc]initWithFrame:CGRectMake(self.center.x-190/2*self.frame.size.height/1080, self.frame.size.height-30-250*self.frame.size.height/1080, 190*self.frame.size.height/1080, 250*self.frame.size.height/1080) andName:@"" andSelectedName:@"" andImageName:@"挂断电话" andImageSelectedName:@"" andSelect:0 andHidden:0];
    self.stopItem.delegate =self;
    [self addSubview:self.stopItem];
    self.changeitem = [[talkItemView alloc]initWithFrame:CGRectMake(self.center.x+190/2*3*self.frame.size.height/1080, self.frame.size.height-30-250*self.frame.size.height/1080, 190*self.frame.size.height/1080, 250*self.frame.size.height/1080) andName:@"切换摄像头" andSelectedName:@"切换摄像头" andImageName:@"切换摄像头.png" andImageSelectedName:@"切换摄像头selected.png" andSelect:0 andHidden:0];
    self.changeitem.delegate = self;
    [self addSubview:self.changeitem];
}

- (void)createTimeLabel
{
    self.timerLabel  = [[QLtimerLabel alloc]initWithFrame:CGRectMake(CGRectGetMinX(self.stopItem.frame), 600*self.frame.size.height/1080, self.stopItem.frame.size.width, 30)];
    [self setFontSizeThatFits:self.timerLabel];
    self.timerLabel.center = CGPointMake(self.center.x, self.timerLabel.center.y);
    [self addSubview:self.timerLabel];
}

- (void)todo:(NSString *)work
{
    if ([work isEqualToString:@"切换摄像头"])
    {
        [self.delegate changeCamera];
    }
    else if([work isEqualToString:@"静音"])
    {
        [self.delegate mute];
    }
    else
    {
        [self.delegate stop];
    }
}

#pragma mark - 共有方法
- (void)setFontSizeThatFits:(UILabel*)label
{
    CGFloat fontSizeThatFits;
    [label.text sizeWithFont:label.font
                 minFontSize:12.0   //最小字体
              actualFontSize:&fontSizeThatFits
                    forWidth:label.bounds.size.width
               lineBreakMode:NSLineBreakByWordWrapping];
    label.font = [label.font fontWithSize:fontSizeThatFits];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
