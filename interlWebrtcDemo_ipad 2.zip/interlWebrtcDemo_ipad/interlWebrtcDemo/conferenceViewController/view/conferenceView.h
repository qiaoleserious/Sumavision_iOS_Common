//
//  conferenceView.h
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Woogeen/Woogeen.h>
@protocol conferenceDelegate<NSObject>
- (void)stop;
- (void)mute;
- (void)changeCamera;
@end
@interface conferenceView : UIView
@property(nonatomic,strong)id<conferenceDelegate>delegate;
@property(nonatomic,readonly) RTCCameraPreviewView *localVideoView;
@property(nonatomic,readonly) UIView<RTCVideoRenderer> *remoteVideoView;


@property(nonatomic, strong) NSString* stats;
- (instancetype)initWithFrame:(CGRect)frame
                     Delegate:(id<conferenceDelegate>)delegate;
@end
