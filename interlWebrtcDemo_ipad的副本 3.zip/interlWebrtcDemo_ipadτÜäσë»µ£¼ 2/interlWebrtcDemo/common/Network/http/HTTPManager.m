//
//  HTTPManager.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "HTTPManager.h"
#import <AFHTTPSessionManager.h>
#import "ql_hud_manager.h"
@interface HTTPManager()
@property(nonatomic,strong)AFHTTPSessionManager * SessionManager;
@end
@implementation HTTPManager
static  HTTPManager * qlmanager = nil;
+ (instancetype)share_http_manager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!qlmanager)
        {
            qlmanager = [[HTTPManager alloc]init];
        }
    });
    return qlmanager;
}

- (instancetype)init
{
    if ((qlmanager = [super  init]))
    {
        qlmanager.SessionManager = [AFHTTPSessionManager manager];
        qlmanager.SessionManager.requestSerializer = [AFJSONRequestSerializer serializer];
        qlmanager.SessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [qlmanager.SessionManager.requestSerializer setValue:@"*/*" forHTTPHeaderField:@"Accept"];
        [qlmanager.SessionManager.requestSerializer setTimeoutInterval:6];
        [qlmanager.SessionManager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        qlmanager.SessionManager.securityPolicy.allowInvalidCertificates=YES;
        qlmanager.SessionManager.securityPolicy.validatesDomainName=NO;
    }
    return qlmanager;
}

+ (void)post_with_Url:(NSString *)url param:(NSDictionary *)param log:(NSString *)log haveHud:(BOOL)haveHud sucHandle:(SucBlock)sucHandle falhandel:(FaiBlock)falHandle
{
    [self share_http_manager];
    if (haveHud)
    {
        [ql_hud_manager showWithStatus:@"loading..."];
    }
    [qlmanager.SessionManager POST:url parameters:param progress:^(NSProgress * _Nonnull uploadProgress)
    {} success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject)
    {
        [ql_hud_manager dismiss];
        NSData * data = [[NSData alloc]initWithData:responseObject];
        sucHandle(data);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error)
    {
        [ql_hud_manager dismiss];
        falHandle(error);
    }];
}
@end
