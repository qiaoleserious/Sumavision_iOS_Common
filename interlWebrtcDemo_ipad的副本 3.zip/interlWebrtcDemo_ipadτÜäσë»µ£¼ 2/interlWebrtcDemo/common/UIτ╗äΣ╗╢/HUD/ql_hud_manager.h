//
//  ql_hud_manager.h
//  BVCforIphone
//
//  Created by 乔乐 on 2017/6/26.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SVProgressHUD.h"
@interface ql_hud_manager : NSObject
+ (void)show;
+ (void)showWithStatus:(NSString*)status;
+ (void)dismiss;
+ (void)showInfoWithStatus:(NSString*)status;
+ (void)dismissWithDelay:(NSTimeInterval)time;

//横屏提示框
+ (void)showHorizontalInfo:(NSString*)info;
@end
