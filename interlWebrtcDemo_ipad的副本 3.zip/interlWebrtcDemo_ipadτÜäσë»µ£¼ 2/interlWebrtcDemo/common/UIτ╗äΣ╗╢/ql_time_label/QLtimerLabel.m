//
//  QLtimerLabel.m
//  BVCforIphone
//
//  Created by 乔乐 on 17/3/19.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "QLtimerLabel.h"
#import "UIView+createFrame.h"
@implementation QLtimerLabel
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.Timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:self.Timer forMode:NSDefaultRunLoopMode];
        self.text = [NSString stringWithFormat:@"%02d:%02d:%02d",self.hour,self.minute,self.second];
        if (IPHONE4)
        {
            self.font = [UIFont fontWithName:@"SOURCEHANSANSCN-REGULAR" size:9];
        }else
        {
            self.font = [UIFont fontWithName:@"SOURCEHANSANSCN-REGULAR" size:12];
        }
        self.adjustsFontSizeToFitWidth = YES;
        self.textColor = [UIColor whiteColor];
        self.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}

- (void)startTimer
{
    self.second ++;
    if (self.second ==60)
    {
        self.minute++;
        self.second =0;
    }
    if (self.minute == 60)
    {
        self.hour++;
        self.minute = 0;
    }
    self.text = [NSString stringWithFormat:@"%02d:%02d:%02d",self.hour,self.minute,self.second];
}
- (NSString*)stop
{
    [self.Timer invalidate];
    self.Timer = nil;
    return self.text;
}
- (void)appear
{
    self.hidden = NO;
}
- (void)hidden
{
    self.hidden = YES;
}
@end
