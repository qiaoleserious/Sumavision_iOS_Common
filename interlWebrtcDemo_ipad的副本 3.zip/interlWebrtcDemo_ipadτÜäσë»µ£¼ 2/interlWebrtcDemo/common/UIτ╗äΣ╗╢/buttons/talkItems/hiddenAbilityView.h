//
//  hiddenAbilityView.h
//  BVCforIphone
//
//  Created by 乔乐 on 2018/1/9.
//  Copyright © 2018年 乔乐. All rights reserved.


//具有控制隐藏属性的视图

#import <UIKit/UIKit.h>

@interface hiddenAbilityView : UIView
@property(nonatomic,strong)NSTimer * timer;
- (void)hidden;
- (void)appear;
@end
