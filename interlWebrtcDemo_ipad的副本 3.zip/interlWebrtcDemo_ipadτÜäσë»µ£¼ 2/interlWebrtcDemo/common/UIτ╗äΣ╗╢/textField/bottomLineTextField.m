//
//  bottomLineTextField.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/11.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "bottomLineTextField.h"

@implementation bottomLineTextField
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        self.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [UIColor colorWithRed:80/255.0 green:126/255.0 blue:250/255.0 alpha:1].CGColor);
    CGContextFillRect(context, CGRectMake(0, CGRectGetHeight(self.frame)-1, CGRectGetWidth(self.frame), 1));
}
@end
