//
//  conferenceViewController.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "conferenceViewController.h"
#import <Woogeen/Woogeen.h>
#import "conferenceView.h"
#import "AppDelegate.h"
#import "BrightenFilter.h"
@interface conferenceViewController ()<RTCRemoteMixedStreamObserver,conferenceDelegate>

@property(strong, nonatomic) RTCRemoteCameraStream* remoteStream;
@property(strong, nonatomic) RTCConferenceClient* conferenceClient;
@property(nonatomic,strong) conferenceView * conView;
@property(strong, nonatomic) RTCLocalStream * localStream;
@property(nonatomic)NSInteger * cameraPosition;
@property(nonatomic,assign)BOOL audio;
@property(nonatomic,assign)BOOL haveCurrentStream;
@end

@implementation conferenceViewController
{
     AppDelegate *appDelegate;
    NSTimer* _getStatsTimer;
    RTCVideoSource * _source;
    RTCCameraVideoCapturer * _capturer;
     BrightenFilter* _filter;
}
- (instancetype)init
{
    if (self = [super init])
    {
        self.haveCurrentStream = 0;
        self.cameraPosition = 2;
        self.audio = 1;
        appDelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
        _conferenceClient=[appDelegate conferenceClient];
       
        _remoteStream = [[RTCRemoteCameraStream alloc]init];
    }
    return self;
}
- (void)loadView
{
    [super loadView];
    self.conView = [[conferenceView alloc]initWithFrame:[UIScreen mainScreen].bounds Delegate:self];
    self.view = self.conView;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"OnStreamAdded" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"OnStreamRemoved" object:nil];
}
#pragma mark - delegate
- (void)stop
{
    [_conferenceClient leaveWithOnSuccess:^{
        [self quitConference];
    } onFailure:^(NSError* err){
        [self quitConference];
        NSLog(@"Failed to leave. %@",err);
    }];
}

- (void)changeCamera
{
        if(_capturer){
            [_capturer stopCapture];
            if (_cameraPosition==1)
            {
                [self setCamera:2 audio:self.audio];
                self.cameraPosition = 2;
            }else
            {
                [self setCamera:1 audio:self.audio];
                self.cameraPosition = 1;
            }
        }
}

- (void)mute
{
        if(_capturer){
            [_capturer stopCapture];
            if (_audio==1)
            {
//                [self setCamera:2 audio:0];
               
                [_localStream disableAudio];
                 self.audio = 0;
            }else
            {
                //[self setCamera:1 audio:1];
                [_localStream enableAudio];
                self.audio = 1;
            }
        }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onStreamAddedNotification:) name:@"OnStreamAdded" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onStreamRemovedNotification:) name:@"OnStreamRemoved" object:nil];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self doPublish:_cameraPosition];
    });
    // Do any additional setup after loading the vie
    
}

- (void)viewWillAppear:(BOOL)animated {
    [self handleLocalPreviewOrientation];
}

- (void)handleLocalPreviewOrientation{
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    switch(orientation){
        case UIInterfaceOrientationLandscapeLeft:
            [self.conView.localVideoView setTransform:CGAffineTransformMakeRotation(M_PI_2)];
            self.conView.localVideoView.frame = CGRectMake(self.view.frame.size.width-self.conView.localVideoView.frame.size.width, 0, self.conView.localVideoView.frame.size.width, self.conView.localVideoView.frame.size.height);
            break;
        case UIInterfaceOrientationLandscapeRight:
            [self.conView.localVideoView setTransform:CGAffineTransformMakeRotation(M_PI+M_PI_2)];
          //  [self.conView.remoteVideoView setTransform:CGAffineTransformMakeRotation(M_PI+M_PI_2)];
            break;
        default:
            NSLog(@"Unsupported orientation.");
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)quitConference{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:nil];
        _localStream = nil;
        [_getStatsTimer invalidate];
        if(_capturer){
            [_capturer stopCapture];
        }
        
    });
}


- (void)onStreamRemovedNotification:(NSNotification*)notification {
    NSDictionary* userInfo = notification.userInfo;
    RTCRemoteStream* stream = userInfo[@"stream"];
    NSLog(@"New stream leave from %@", [stream getRemoteUserId]);
    NSUserDefaults * defaluts = [NSUserDefaults standardUserDefaults];
    NSString * localUserId = [defaluts stringForKey:@"localStreamGetUserId"];
    if (![[stream getRemoteUserId] isEqualToString:localUserId])
    {
         [self stop];
    }
   
}

- (void)onStreamAddedNotification:(NSNotification*)notification {
    NSDictionary* userInfo = notification.userInfo;
    RTCRemoteStream* stream = userInfo[@"stream"];
    NSLog(@"New stream add from %@", [stream getRemoteUserId]);
    if (!self.haveCurrentStream)
    {
         [self subscribe1];
    }
}


- (void)setCamera:(NSInteger)position audio:(BOOL)audio;
{
    NSError *err=[[NSError alloc]init];
    _localStream=[[RTCLocalCameraStream alloc]initWithAudioEnabled:audio VideoSource:_source error: &err];
    _capturer=[[RTCCameraVideoCapturer alloc] initWithDelegate:_filter];
    
    for (AVCaptureOutput* output  in _capturer.captureSession.outputs)
    {
        if ([output isKindOfClass:[AVCaptureVideoDataOutput class]])
        {
           AVCaptureConnection * videoConnection = [output connectionWithMediaType:AVMediaTypeVideo];
            [videoConnection setVideoOrientation:AVCaptureVideoOrientationLandscapeRight];
        }
    }
    AVCaptureDevice* device=nil;
    for (AVCaptureDevice *d in [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo]){
        if (d.position==position){
            device=d;
            //NSLog(@"Supported resolution: %@", device.formats);
        }
    }
    NSAssert(device!=nil,@"Cannot find suitable camera device.");
    AVCaptureDeviceFormat* format=nil;
    NSArray<AVCaptureDeviceFormat*> *formats=[RTCCameraVideoCapturer supportedFormatsForDevice:device];
    for(AVCaptureDeviceFormat* f in formats){
        CMVideoDimensions dimension=CMVideoFormatDescriptionGetDimensions(f.formatDescription);
        if(dimension.width==640&&dimension.height==480){
            format=f;
            break;
        }
    }
    //NSAssert(format!=nil,@"Cannot find suitable format.");
    Float64 maxFramerate=0;
    for(AVFrameRateRange *fpsRange in format.videoSupportedFrameRateRanges){
        maxFramerate=fmax(maxFramerate,fpsRange.maxFrameRate);
    }
    [_capturer startCaptureWithDevice:device format:format fps:maxFramerate];
    dispatch_async(dispatch_get_main_queue(), ^{
        // As RTCCameraPreviewView renders video frame an AVCaptureSession, it does not reflect filter applied. If you want to show filtered video, please attach LocalStream to RTCVideoRenderer.
        [((conferenceView *)self.view).localVideoView setCaptureSession:[_capturer captureSession] ];
    });
   
}

-(void)doPublish:(NSInteger)posotion{
    if (_localStream == nil) {
#if TARGET_IPHONE_SIMULATOR
        NSLog(@"Camera is not supported on simulator");
        RTCLocalCameraStreamParameters* parameters=[[RTCLocalCameraStreamParameters alloc]initWithVideoEnabled:NO audioEnabled:YES];
#else
       
        _source=[RTCFactory videoSource];
        _filter=[[BrightenFilter alloc]initWithOutput: _source];
        [self setCamera:posotion audio:self.audio];
#endif
       
       
#if TARGET_IPHONE_SIMULATOR
        NSLog(@"Stream does not have video track.");
#else
       
#endif
        [_conferenceClient publish:_localStream onSuccess:^() {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"publish success!");
            });
        } onFailure:^(NSError* err) {
            NSLog(@"publish failure!");
            //[self showMsg:[err localizedFailureReason]];
        }];
    }
}

- (void)subscribe1
{
    self.haveCurrentStream = 1;
    _remoteStream = appDelegate.cameraStream;
    [[AVAudioSession sharedInstance]
     overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker
     error:nil];
    RTCConferenceSubscribeOptions* subOption =
    [[RTCConferenceSubscribeOptions alloc] init];
    subOption.videoQualityLevel = RTCConferenceVideoQualityLevelStandard;
    _getStatsTimer = [NSTimer timerWithTimeInterval:1.0
                                             target:self
                                           selector:@selector(printStats)
                                           userInfo:nil
                                            repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_getStatsTimer
                              forMode:NSDefaultRunLoopMode];

    [_conferenceClient subscribe:_remoteStream withOptions:subOption onSuccess:^(RTCRemoteStream * _Nonnull stream) {
        NSLog(@"%s 第%d行 %@",__func__,__LINE__,stream.getRemoteUserId);

        dispatch_async(dispatch_get_main_queue(), ^{
            _remoteStream = stream;
            NSLog(@"Subscribe stream success.");
            [_remoteStream attach:((conferenceView*)self.view).remoteVideoView];

            // [self printStats];
        });
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"%s 第%d行 %@",__func__,__LINE__,error.description);
    }];
    
//    [_conferenceClient subscribe:_remoteStream onSuccess:^(RTCRemoteStream * _Nonnull stream) {
//        NSLog(@"%s 第%d行 %@",__func__,__LINE__,stream.getRemoteUserId);
//        dispatch_async(dispatch_get_main_queue(), ^{
//            _remoteStream = stream;
//            NSLog(@"Subscribe stream success.");
//            [stream attach:((conferenceView*)self.view).remoteVideoView];
//
//           // [self printStats];
//        });
//    } onFailure:^(NSError * _Nonnull error) {
//        NSLog(@"%s 第%d行 %@",__func__,__LINE__,error.description);
//    }];
}

-(void)printStats{
    [_conferenceClient getConnectionStatsForStream:_remoteStream onSuccess:^(RTCConnectionStats *stats) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSMutableString* statsString=[NSMutableString stringWithFormat:@"Mixed stream info:\nAvaiable: %lukbps\n",(unsigned long)stats.videoBandwidthStats.availableReceiveBandwidth/1024];
            for(id channel in stats.mediaChannelStats){
                if([channel isKindOfClass:[RTCVideoReceiverStats class]]){
                    RTCVideoReceiverStats* videoReceiverStats=channel;
                    NSMutableString *channelStats=[NSMutableString stringWithFormat:@"Packets lost: %lu\nResolution: %dx%d\nDelay: %lu\nVideo Codec: %@\n", (unsigned long)videoReceiverStats.packetsLost,(unsigned int)videoReceiverStats.frameResolution.width,(unsigned int)videoReceiverStats.frameResolution.height,  (unsigned long)videoReceiverStats.delay, videoReceiverStats.codecName];
                    [statsString appendString:channelStats];
                }
            }
            _conView.stats=statsString;
        });
    } onFailure:^(NSError *e) {
        dispatch_async(dispatch_get_main_queue(), ^{
            _conView.stats=@"";
        });
    }];
}
-(void)onVideoLayoutChanged{
    NSLog(@"OnVideoLayoutChanged.");
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
