//
//  AppDelegate.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/8.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "AppDelegate.h"
#import "loginViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    loginViewController * login = [[loginViewController alloc]init];
    self.window.rootViewController  = login;
    [self.window makeKeyAndVisible];
   // _cameraStream = [[RTCRemoteCameraStream alloc]init];
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark - rtcDelegate

- (RTCConferenceClient*)conferenceClient{
    if (_conferenceClient==nil){
        //NSString* path=[[NSBundle mainBundle]pathForResource:@"audio_long16" ofType:@"pcm"];
        //FileAudioFrameGenerator* generator=[[FileAudioFrameGenerator alloc]initWithPath:path sampleRate:16000 channelNumber:1];
        //[RTCGlobalConfiguration setCustomizedAudioInputEnabled:YES audioFrameGenerator:generator];
        RTCConferenceClientConfiguration* config=[[RTCConferenceClientConfiguration alloc]init];
        NSArray *ice=[[NSArray alloc]initWithObjects:[[RTCIceServer alloc]initWithURLStrings:[[NSArray alloc]initWithObjects:@"stun:61.152.239.47:3478", nil]], nil];
        config.ICEServers=ice;
        config.mediaCodec.videoCodec=VideoCodecH264;
        _conferenceClient=[[RTCConferenceClient alloc]initWithConfiguration:config];
        
        [_conferenceClient addObserver:self];
        //[_conferenceClient removeObserver:self];
    }
    return _conferenceClient;
}

-(void)onStreamAdded:(RTCRemoteStream *)stream{
    NSLog(@"AppDelegate on stream added");
    
    if ([stream isKindOfClass:[RTCRemoteCameraStream class]])
    {
        NSUserDefaults * defaluts = [NSUserDefaults standardUserDefaults];
        NSString * localUserId = [defaluts stringForKey:@"localStreamGetUserId"];
        NSLog(@"%s 第%d行 userId:%@",__func__,__LINE__,localUserId);
        if (![stream.getRemoteUserId isEqualToString:localUserId])
        {
            NSLog(@"%s 第%d行 streamId:%@",__func__,__LINE__,stream.getRemoteUserId);
            //_cameraStream = [[RTCRemoteCameraStream alloc]init];
            _cameraStream = stream;
             [[NSNotificationCenter defaultCenter] postNotificationName:@"OnStreamAdded" object:self userInfo:[NSDictionary dictionaryWithObject:stream forKey:@"stream"]];
        }
        
    }
}

-(void)onStreamRemoved:(RTCRemoteStream *)stream {
    NSLog(@"Appdelegate on stream removed");
    
    if ([stream isKindOfClass:[RTCRemoteCameraStream class]])
    {
        NSUserDefaults * defaluts = [NSUserDefaults standardUserDefaults];
        NSString * localUserId = [defaluts stringForKey:@"localStreamGetUserId"];
        if (![stream.getRemoteUserId isEqualToString:localUserId])
        {
         [[NSNotificationCenter defaultCenter]postNotificationName:@"OnStreamRemoved" object:self userInfo:[NSDictionary dictionaryWithObject:stream forKey:@"stream"]];
        }
    }
   
}

-(void)onMessageReceivedFrom:(NSString *)senderId message:(NSString *)message{
    NSLog(@"AppDelegate received message: %@, from %@", message, senderId);
}

-(void)onUserJoined:(RTCConferenceUser *)user{
    NSLog(@"AppDelegate received user join event: %@",[user getUserId]);
}

-(void)onUserLeft:(RTCConferenceUser *)user
{
    NSLog(@"AppDelegate received user leave event: %@",[user getUserId]);
}

- (void) onServerDisconnected{
    NSLog(@"Server disconnected");
    //_mixedStream = nil;
   // _cameraStream = nil;
}

-(void)onVideoLayoutChanged{
    NSLog(@"OnVideoLayoutChanged.");
}

-(void)onStreamError:(NSError *)error forStream:(RTCStream *)stream{
    NSLog(@"OnStreamError");
}


@end
