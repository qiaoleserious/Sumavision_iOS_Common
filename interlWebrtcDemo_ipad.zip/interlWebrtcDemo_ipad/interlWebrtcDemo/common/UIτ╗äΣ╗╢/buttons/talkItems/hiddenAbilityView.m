//
//  hiddenAbilityView.m
//  BVCforIphone
//
//  Created by 乔乐 on 2018/1/9.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "hiddenAbilityView.h"

@implementation hiddenAbilityView
- (void)hidden
{
    [self.timer invalidate];
    self.timer = nil;
    self.hidden =YES;
    self.userInteractionEnabled = NO;
    
}

- (void)appear
{
    self.hidden = NO;
    self.userInteractionEnabled = YES;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(hidden) userInfo:nil repeats:NO];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
