//
//  talkItemView.h
//  BVCforIphone
//
//  Created by 乔乐 on 17/3/17.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "hiddenAbilityView.h"
#define defaultInterval 1
@protocol talkItemViewDelegate<NSObject>
-(void)todo:(NSString*)work;
@end
@interface talkItemView : hiddenAbilityView
@property (nonatomic, assign) NSTimeInterval timeInterval;
@property(nonatomic,copy)NSString * name;
@property(nonatomic,copy)NSString * selectedName;
@property(nonatomic,copy)NSString * imageName;
@property(nonatomic,assign)id<talkItemViewDelegate>delegate;

- (talkItemView*)initWithFrame:(CGRect)frame
                       andName:(NSString*)name
               andSelectedName:(NSString*)selectedName
                  andImageName:(NSString*)imageName
          andImageSelectedName:(NSString*)seclectedName
                     andSelect:(BOOL)select
                     andHidden:(BOOL)hidden;

- (talkItemView*)initWithFrame:(CGRect)frame
                       andName:(NSString *)name
                  andImageName:(NSString *)imageName;



@end
