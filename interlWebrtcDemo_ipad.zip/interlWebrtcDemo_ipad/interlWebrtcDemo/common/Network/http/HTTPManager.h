//
//  HTTPManager.h
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/12.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void(^SucBlock)(NSData * data);
typedef void(^FaiBlock)(NSError * error);
@interface HTTPManager : NSObject
+ (void)post_with_Url:(NSString*)url
            param:(NSDictionary*)param
                  log:(NSString*)log
              haveHud:(BOOL)haveHud
            sucHandle:(SucBlock)sucHandle
            falhandel:(FaiBlock)falHandle;
@end
