//
//  loginViewController.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/8.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "loginViewController.h"
#import "loginView.h"
#import "HTTPManager.h"
#import "standbyViewController.h"
#import "ql_hud_manager.h"
@interface loginViewController ()<loginDelegate>
@property(nonatomic,strong)loginView * backgroundView;
@end

@implementation loginViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.backgroundView = [[loginView alloc]initWithDelegate:self];
    [self.view addSubview:self.backgroundView];
}

- (void)login:(NSString *)ip
{
//    NSDictionary *params = [[NSDictionary alloc]initWithObjectsAndKeys:@"", @"room", @"user", @"username", @"presenter", @"role", nil];
//    [HTTPManager post_with_Url:[ip stringByAppendingString:@"createToken/"] param:params log:@"登录" haveHud:1 sucHandle:^(NSData *data)
//    {
        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:ip forKey:@"userIP"];
        standbyViewController * stand = [[standbyViewController alloc]initWithData:nil];
        [self presentViewController:stand animated:YES completion:nil];
//    } falhandel:^(NSError *error) {
//        [ql_hud_manager showInfoWithStatus:@"请输入正确IP"];
//    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
