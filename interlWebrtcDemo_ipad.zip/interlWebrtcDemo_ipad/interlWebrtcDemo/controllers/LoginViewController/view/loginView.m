//
//  loginView.m
//  interlWebrtcDemo
//
//  Created by 乔乐 on 2018/3/9.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import "loginView.h"
#import "voiceButton.h"
#import <Masonry.h>
#import "UIColor+hex.h"
#import "bottomLineTextField.h"
#import "ql_hud_manager.h"

@interface loginView()<UITextFieldDelegate>
@property(nonatomic,strong)bottomLineTextField * ipTextFiled;
@property(nonatomic,strong)voiceButton * loginBtn;
@end
@implementation loginView

- (instancetype)initWithDelegate:(id<loginDelegate>)delegate
{
    if (self = [super init])
    {
        self.frame = [UIScreen mainScreen].bounds;
        self.delegate = delegate;
        self.image = [UIImage imageNamed:@"loginBackgroundView.png"];
        self.userInteractionEnabled = YES;
        [self createUI];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
        

    }
    return self;
}

- (void)createUI
{
    self.ipTextFiled = [[bottomLineTextField alloc]initWithFrame:CGRectZero];
    [self addSubview:self.ipTextFiled];
    self.ipTextFiled.delegate = self;
    self.ipTextFiled.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"IP" attributes:@{NSForegroundColorAttributeName: [UIColor colorWithHexString:@"#98afd1"]}];
    self.ipTextFiled.textAlignment = NSTextAlignmentCenter;
    [self.ipTextFiled mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.top.mas_equalTo(self.frame.size.height*800/1530);
        make.size.mas_equalTo(CGSizeMake(self.frame.size.width*750/2037, self.frame.size.width*750/2037/7));
    }];
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    if (![self isBlankString:[defaults stringForKey:@"userIP"]])
    {
        self.ipTextFiled.text = [defaults stringForKey:@"userIP"];
    }
    [self.ipTextFiled sizeToFit];
    self.loginBtn = [[voiceButton alloc]initWithFrame:CGRectZero];
    [self addSubview:self.loginBtn];
    [self.loginBtn addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
//    [self.loginBtn addTarget:self action:@selector(pressLogin:) forControlEvents:UIControlEventTouchDown];
//    [self.loginBtn addTarget:self action:@selector(cancelLogin:) forControlEvents:UIControlEventTouchUpOutside];
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
    make.top.equalTo(self.ipTextFiled.mas_bottom).offset(self.frame.size.height*85/1530);
        make.centerX.equalTo(self);
    make.size.mas_equalTo(CGSizeMake(self.frame.size.width*552/2037,self.frame.size.width*552/2037*100/550 ));
    }];
    [self.loginBtn setImage:[UIImage imageNamed:@"登录.png"] forState:UIControlStateNormal];
    [self.loginBtn setImage:[UIImage imageNamed:@"登录selected.png"] forState:UIControlStateSelected];
}
#pragma mark - login
- (void)login
{
    if (![self isBlankString:self.ipTextFiled.text])
    {
        [self.delegate login:self.ipTextFiled.text];
    }
    else
    {
        [ql_hud_manager showInfoWithStatus:@"请输入正确IP"];
        [self.ipTextFiled becomeFirstResponder];
    }
}

//- (void)pressLogin:(UIButton*)login
//{
//    [UIView animateWithDuration:0.15 animations:^{
//        login.transform = CGAffineTransformMakeScale(0.9, 0.9);
//    }];
//}
//
//- (void)cancelLogin:(UIButton*)login
//{
//    [UIView animateWithDuration:0.15 animations:^{
//        login.transform = CGAffineTransformMakeScale(1.0, 1.0);}];
//}
#pragma marks - 判断字符串长度
- (BOOL) isBlankString:(NSString *)string
{
    if (string == nil || string == NULL)
    {
        return YES;
    }
    if ([string isKindOfClass:[NSNull class]])
    {
        return YES;
    }
    if ([[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0)
    {
        return YES;
    }
    return NO;
}


#pragma mark - keyboard events -

///键盘显示事件
- (void) keyboardWillShow:(NSNotification *)notification {
    //获取键盘高度，在不同设备上，以及中英文下是不同的
    CGFloat kbHeight = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    
    //计算出键盘顶端到inputTextView panel底端的距离(加上自定义的缓冲距离INTERVAL_KEYBOARD)
    CGFloat offset = (_ipTextFiled.frame.origin.y+_ipTextFiled.frame.size.height+20) - (self.frame.size.height - kbHeight);
    
    // 取得键盘的动画时间，这样可以在视图上移的时候更连贯
    double duration = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    //将视图上移计算好的偏移
    if(offset > 0) {
        [UIView animateWithDuration:duration animations:^{
            self.frame = CGRectMake(0.0f, -offset, self.frame.size.width, self.frame.size.height);
        }];
    }
}

///键盘消失事件
- (void) keyboardWillHide:(NSNotification *)notify {
    // 键盘动画时间
    double duration = [[notify.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    //视图下沉恢复原状
    [UIView animateWithDuration:duration animations:^{
        self.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    }];
}
#pragma mark - textfiled delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
   
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
